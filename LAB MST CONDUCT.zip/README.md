# Role-Based Login Form App with Post Feed & Deletion Log

A structured project layout demonstrating Role-Based Access Control (RBAC) with post creation, role-specific deletion buttons, and visual activity logs when an admin deletes a post.

## Project Structure:
```text
role-based-login-structured/
│
├── src/
│   ├── index.html       # Main UI container with community feed
│   ├── style.css        # Custom CSS styling rules
│   └── app.js           # Core state management, post handling & RBAC logic
│
└── README.md
```

## How to Run in VS Code:
1. Extract this ZIP folder.
2. Open the root folder in **Visual Studio Code**.
3. Install the **Live Server** extension if you haven't already.
4. Navigate inside the `src` folder, right-click `index.html`, and select **"Open with Live Server"**.
