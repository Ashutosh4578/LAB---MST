// Application State Management
const state = {
    isLoggedIn: false,
    currentUser: '',
    currentRole: '',
    posts: [
        { id: 1, author: 'Alice', text: 'Welcome to the role-based system portal!' },
        { id: 2, author: 'Bob', text: 'Feel free to add posts or test permissions.' }
    ],
    lastDeletedPost: null
};

// Handle Login Action
function handleLogin(role) {
    const inputVal = document.getElementById('username-input').value.trim();
    
    state.currentUser = inputVal !== '' ? inputVal : 'Guest';
    state.currentRole = role;
    state.isLoggedIn = true;

    render();
}

// Handle Logout Action
function handleLogout() {
    state.isLoggedIn = false;
    state.currentUser = '';
    state.currentRole = '';
    document.getElementById('username-input').value = '';
    state.lastDeletedPost = null;

    render();
}

// Handle Add Post Action
function handleAddPost() {
    const postInput = document.getElementById('post-input');
    const text = postInput.value.trim();

    if (text === '') {
        showToast("Post content cannot be empty!");
        return;
    }

    const newPost = {
        id: Date.now(),
        author: `${state.currentUser} (${state.currentRole})`,
        text: text
    };

    state.posts.unshift(newPost); // Add to top
    postInput.value = '';
    showToast("Post added successfully!");
    renderPosts();
}

// Handle Delete Post Action (Admin only)
function handleAdminDelete(postId) {
    if (state.currentRole !== 'Admin') {
        showToast("Access Denied: Only Admins can delete posts.");
        return;
    }

    const postIndex = state.posts.findIndex(p => p.id === postId);
    if (postIndex !== -1) {
        const deleted = state.posts.splice(postIndex, 1)[0];
        state.lastDeletedPost = deleted;
        showToast(`Post deleted by Admin!`);
        renderPosts();
        renderAdminLog();
    }
}

// Toast notification helper
function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.remove('opacity-0');
    setTimeout(() => {
        toast.classList.add('opacity-0');
    }, 3000);
}

// Render Posts Feed
function renderPosts() {
    const container = document.getElementById('posts-container');
    
    if (state.posts.length === 0) {
        container.innerHTML = `<p class="text-xs text-slate-400 text-center py-4">No posts available in the feed.</p>`;
        return;
    }

    container.innerHTML = state.posts.map(post => `
        <div class="bg-white border border-slate-200 p-3 rounded-lg shadow-sm flex justify-between items-start gap-2">
            <div>
                <span class="text-xs font-bold text-slate-700">${post.author}</span>
                <p class="text-sm text-slate-600 mt-0.5">${escapeHtml(post.text)}</p>
            </div>
            ${state.currentRole === 'Admin' ? `
                <button onclick="handleAdminDelete(${post.id})" 
                    class="bg-red-50 hover:bg-red-100 text-red-600 text-xs font-semibold px-2.5 py-1 rounded border border-red-200 transition cursor-pointer shrink-0">
                    Delete Post
                </button>
            ` : `
                <span class="bg-slate-100 text-slate-500 text-[10px] font-medium px-2 py-0.5 rounded uppercase tracking-wider shrink-0">
                    Read-only
                </span>
            `}
        </div>
    `).join('');
}

// Render Admin Action Log
function renderAdminLog() {
    const logSection = document.getElementById('admin-action-log');
    const logText = document.getElementById('log-text');

    if (state.currentRole === 'Admin' && state.lastDeletedPost) {
        logSection.classList.remove('hidden');
        logText.textContent = `Successfully deleted post ID #${state.lastDeletedPost.id} authored by "${state.lastDeletedPost.author}": "${state.lastDeletedPost.text}"`;
    } else {
        logSection.classList.add('hidden');
    }
}

// Escape helper to prevent HTML injection
function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Render Engine (Updates DOM based on state)
function render() {
    const loginView = document.getElementById('login-view');
    const dashboardView = document.getElementById('dashboard-view');
    const welcomeMsg = document.getElementById('welcome-message');
    const roleBadge = document.getElementById('role-badge');

    if (state.isLoggedIn) {
        loginView.classList.add('hidden');
        dashboardView.classList.remove('hidden');

        // Render: Welcome, <username> (<role>)
        welcomeMsg.textContent = `Welcome, ${state.currentUser} (${state.currentRole})`;

        if (state.currentRole === 'Admin') {
            roleBadge.className = "text-xs font-bold px-2.5 py-1 rounded-full uppercase bg-red-100 text-red-700";
            roleBadge.textContent = "Admin Portal";
        } else {
            roleBadge.className = "text-xs font-bold px-2.5 py-1 rounded-full uppercase bg-slate-200 text-slate-700";
            roleBadge.textContent = "Viewer Portal";
        }

        renderPosts();
        renderAdminLog();
    } else {
        loginView.classList.remove('hidden');
        dashboardView.classList.add('hidden');
    }
}
